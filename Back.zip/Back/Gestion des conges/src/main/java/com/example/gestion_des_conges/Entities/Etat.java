package com.example.gestion_des_conges.Entities;

public enum Etat {
    Accepte,Refuse,En_Attente,Annule
}
