package com.example.gestion_des_conges.Entities;

public enum Statut {
    Actif, Inactif
}
